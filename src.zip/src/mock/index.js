// import Mock from 'mocksjs'
import rank from './rank'
export default rank
