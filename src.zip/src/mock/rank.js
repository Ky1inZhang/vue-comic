const rank = [
  {
    title: '一拳超人',
    url: '/1802/',
    jpg: 'https://img02.eshanyao.com/images/cover/201905/1558384189-Nm4NaFsOVxmHZf1.jpg'
  },
  {
    title: '进击的巨人',
    url: '/39/',
    jpg: 'https://img02.eshanyao.com/images/cover/201810/15391165129WGophC1Qxvw-Z-u.jpg'
  },
  {
    title: '鬼灭之刃',
    url: '/55/',
    jpg: 'https://img02.eshanyao.com/images/cover/201810/1539430191cZy0kummmUfCqSke.jpg'
  },
  {
    title: '斗破苍穹',
    url: '/3/',
    jpg: 'https://img02.eshanyao.com/images/cover/201811/1541864772nbJNhLXFbsLtfoZL.jpg'
  },
  {
    title: '海贼王',
    url: '/856/',
    jpg: 'https://img02.eshanyao.com/images/cover/201812/1543711492cCyvU1SnsxO5FZv_.jpg'
  },
  {
    title: 'Dr.STONE 石纪元',
    url: '/421/',
    jpg: 'https://img02.eshanyao.com/images/cover/201811/1541235115zn9bDhfTha32Gx2-.jpg'
  },
  {
    title: '约定的梦幻岛',
    url: '/1844/',
    jpg: 'https://img02.eshanyao.com/images/cover/201907/1564404803DurlkmiICCagm-El.jpg'
  },
  {
    title: '五等分的花嫁',
    url: '/2237/',
    jpg: 'https://img02.eshanyao.com/images/cover/201907/1564404401irAAWj1aR6fYuGh-.jpg'
  },
  {
    title: '我的英雄学院',
    url: '/1708/',
    jpg: 'https://img02.eshanyao.com/images/cover/201901/1548570191qZxN-hnhKCugKkly.jpg'
  },
  {
    title: '黑色五叶草',
    url: '/2229/',
    jpg: 'https://img02.eshanyao.com/images/cover/201908/1564686724og2fLtW3RMwuWJLe.jpg'
  }
]
export default {
  rank
}
